$(window).load(function () {
$('#JiSlider').JiSlider({color: '#fff', start: 3, reverse: true}).addClass('ff')
})