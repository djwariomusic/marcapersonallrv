$(document).ready(function() {
	$("#owl-demo2").owlCarousel({
	    items : 1,
	    lazyLoad : false,
	    autoPlay : true,
	    navigation : false,
	    navigationText :  false,
	    pagination : true,
	});
});